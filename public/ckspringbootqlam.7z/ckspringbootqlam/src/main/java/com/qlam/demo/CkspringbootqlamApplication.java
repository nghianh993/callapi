package com.qlam.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CkspringbootqlamApplication {

	public static void main(String[] args) {
		SpringApplication.run(CkspringbootqlamApplication.class, args);
	}
}
