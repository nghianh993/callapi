package com.qlam.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class QController {
	@GetMapping("/")
	public String home() {
		return "adpost";
	}
}
